<?php
session_start();

// Cek Status Login
if (!isset($_SESSION['id_admin']) && !isset($_SESSION['id_user'])) {
    header("Location: ../login.php");
    exit();
}

// Load Koneksi Database
if (file_exists("../koneksi.php")) {
    include "../koneksi.php";
} elseif (file_exists("../config/koneksi.php")) {
    include "../config/koneksi.php";
}

if (!isset($conn) && isset($koneksi)) {
    $conn = $koneksi;
}

// Query untuk mengambil data buku (untuk dropdown pilih buku)
$q_buku = mysqli_query($conn, "SELECT * FROM buku ORDER BY id_buku DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Peminjaman | Sistem Perpustakaan</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        body {
            background-color: #f4f6f9;
        }

        /* Navbar Header Atas */
        .navbar-custom {
            background-color: #0d6efd;
            padding: 15px 30px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        /* Tulisan Dashboard Diperbesar */
        .brand-text {
            font-size: 1.75rem; /* Diperbesar */
            font-weight: 800;
            color: #ffffff;
            letter-spacing: 0.5px;
        }

        /* Tombol Kembali Menarik (Glassmorphism / Glow Pill) */
        .btn-kembali-custom {
            background: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            border: 1px solid rgba(255, 255, 255, 0.4);
            backdrop-filter: blur(5px);
            padding: 8px 22px;
            font-size: 1.05rem;
            font-weight: 600;
            border-radius: 50rem;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-kembali-custom:hover {
            background-color: #ffffff;
            color: #0d6efd;
            border-color: #ffffff;
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(255, 255, 255, 0.4);
        }

        /* Styling Card Form Transaksi */
        .card-form {
            border: none;
            border-radius: 16px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
            overflow: hidden;
        }
        .card-form-header {
            background-color: #0d6efd;
            color: white;
            padding: 18px 25px;
            font-size: 1.3rem;
            font-weight: 700;
        }
    </style>
</head>
<body>

    <!-- NAVBAR HEADER ATAS -->
    <nav class="navbar navbar-custom mb-5">
        <div class="container-fluid d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center gap-2">
                <span class="fs-2">📚</span>
                <!-- Tulisan Dashboard Perpustakaan Diperbesar -->
                <span class="brand-text">Dashboard Perpustakaan</span>
            </div>
            <!-- Tombol Kembali Lebih Menarik -->
            <a href="../dashboard.php" class="btn-kembali-custom">
                <i class="bi bi-arrow-left-circle-fill fs-5"></i>
                <span>Kembali</span>
            </a>
        </div>
    </nav>

    <!-- KONTEN FORM PEMINJAMAN -->
    <div class="container mb-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-7">
                
                <div class="card card-form bg-white">
                    <div class="card-form-header">
                        <i class="bi bi-journal-plus me-2"></i> Tambah Transaksi Peminjaman
                    </div>
                    
                    <div class="card-body p-4 p-md-5">
                        <form action="proses_peminjaman.php" method="POST">
                            
                            <!-- 1. NAMA PEMINJAM (Ganti Pilih Anggota) -->
                            <div class="mb-3">
                                <label for="nama_peminjam" class="form-label fw-bold text-dark">Nama Peminjam</label>
                                <input type="text" name="nama_peminjam" id="nama_peminjam" class="form-control form-control-lg fs-6" placeholder="Masukkan nama lengkap peminjam..." required>
                            </div>

                            <!-- 2. INPUT UMUR & JENIS KELAMIN -->
                            <div class="row g-3 mb-3">
                                <div class="col-md-6">
                                    <label for="umur" class="form-label fw-bold text-dark">Umur (Tahun)</label>
                                    <input type="number" name="umur" id="umur" class="form-control form-control-lg fs-6" placeholder="Contoh: 20" min="1" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="jenis_kelamin" class="form-label fw-bold text-dark">Jenis Kelamin</label>
                                    <select name="jenis_kelamin" id="jenis_kelamin" class="form-select form-select-lg fs-6" required>
                                        <option value="" selected disabled>-- Pilih Jenis Kelamin --</option>
                                        <option value="Pria">Pria</option>
                                        <option value="Wanita">Wanita</option>
                                    </select>
                                </div>
                            </div>

                            <!-- 3. PILIH BUKU -->
                            <div class="mb-3">
                                <label for="id_buku" class="form-label fw-bold text-dark">Pilih Buku</label>
                                <select name="id_buku" id="id_buku" class="form-select form-select-lg fs-6" required>
                                    <option value="" selected disabled>-- Pilih Buku --</option>
                                    <?php if ($q_buku && mysqli_num_rows($q_buku) > 0): ?>
                                        <?php while ($buku = mysqli_fetch_assoc($q_buku)): ?>
                                            <option value="<?= $buku['id_buku']; ?>">
                                                <?= htmlspecialchars($buku['judul'] ?? $buku['nama_buku']); ?> (Stok: <?= $buku['stok'] ?? $buku['jumlah'] ?? '0'; ?>)
                                            </option>
                                        <?php endwhile; ?>
                                    <?php else: ?>
                                        <option value="" disabled>Buku tidak tersedia</option>
                                    <?php endif; ?>
                                </select>
                            </div>

                            <!-- 4. TANGGAL PINJAM & TANGGAL KEMBALI -->
                            <div class="row g-3 mb-4">
                                <div class="col-md-6">
                                    <label for="tgl_pinjam" class="form-label fw-bold text-dark">Tanggal Pinjam</label>
                                    <input type="date" name="tgl_pinjam" id="tgl_pinjam" class="form-control form-control-lg fs-6" value="<?= date('Y-m-d'); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <label for="tgl_kembali" class="form-label fw-bold text-dark">Tanggal Kembali</label>
                                    <input type="date" name="tgl_kembali" id="tgl_kembali" class="form-control form-control-lg fs-6" value="<?= date('Y-m-d', strtotime('+7 days')); ?>" required>
                                </div>
                            </div>

                            <!-- TOMBOL SIMPAN -->
                            <button type="submit" name="simpan" class="btn btn-primary btn-lg w-100 fw-bold shadow-sm py-3">
                                <i class="bi bi-check-circle-fill me-1"></i> Simpan Transaksi
                            </button>

                        </form>
                    </div>
                </div>

            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
session_start();

// 1. Cek Status Login
if (!isset($_SESSION['id_admin']) && !isset($_SESSION['id_user'])) {
    header("Location: ../login.php");
    exit();
}

// 2. Load Koneksi Database
if (file_exists("../koneksi.php")) {
    include "../koneksi.php";
} elseif (file_exists("../config/koneksi.php")) {
    include "../config/koneksi.php";
}

if (!isset($conn) && isset($koneksi)) {
    $conn = $koneksi;
}

// 3. Tangkap Data Form Transaksi Peminjaman
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_peminjam = mysqli_real_escape_string($conn, $_POST['nama_peminjam']);
    $umur          = isset($_POST['umur']) ? (int)$_POST['umur'] : 0;
    $jenis_kelamin = isset($_POST['jenis_kelamin']) ? mysqli_real_escape_string($conn, $_POST['jenis_kelamin']) : '';
    $id_buku       = (int)$_POST['id_buku'];
    $tgl_pinjam    = mysqli_real_escape_string($conn, $_POST['tgl_pinjam']);
    $tgl_kembali   = mysqli_real_escape_string($conn, $_POST['tgl_kembali']);
    $status        = "Dipinjam";
    $jumlah_pinjam = 1;

    // --- OTOMATIS TAMBAHKAN KOLOM APABILA BELUM ADA DI TABEL PEMINJAMAN ---
    $check_cols = mysqli_query($conn, "SHOW COLUMNS FROM peminjaman");
    $cols = [];
    if ($check_cols) {
        while ($c = mysqli_fetch_assoc($check_cols)) {
            $cols[] = strtolower($c['Field']);
        }
    }

    if (!in_array('nama_peminjam', $cols)) {
        @mysqli_query($conn, "ALTER TABLE peminjaman ADD COLUMN nama_peminjam VARCHAR(100) NULL");
    }
    if (!in_array('umur', $cols)) {
        @mysqli_query($conn, "ALTER TABLE peminjaman ADD COLUMN umur INT(3) NULL");
    }
    if (!in_array('jenis_kelamin', $cols)) {
        @mysqli_query($conn, "ALTER TABLE peminjaman ADD COLUMN jenis_kelamin VARCHAR(20) NULL");
    }
    if (!in_array('tgl_pinjam', $cols)) {
        @mysqli_query($conn, "ALTER TABLE peminjaman ADD COLUMN tgl_pinjam DATE NULL");
    }
    if (!in_array('tgl_kembali', $cols)) {
        @mysqli_query($conn, "ALTER TABLE peminjaman ADD COLUMN tgl_kembali DATE NULL");
    }
    if (!in_array('status', $cols)) {
        @mysqli_query($conn, "ALTER TABLE peminjaman ADD COLUMN status VARCHAR(50) DEFAULT 'Dipinjam'");
    }

    // --- STEP A: SIMPAN KEPALA TRANSAKSI KE TABEL 'peminjaman' ---
    $sql_head = "INSERT INTO peminjaman (nama_peminjam, umur, jenis_kelamin, tgl_pinjam, tgl_kembali, status) 
                 VALUES ('$nama_peminjam', '$umur', '$jenis_kelamin', '$tgl_pinjam', '$tgl_kembali', '$status')";
    
    $simpan_head = mysqli_query($conn, $sql_head);

    if ($simpan_head) {
        // Ambil ID Peminjaman yang baru dibuat
        $id_peminjaman_baru = mysqli_insert_id($conn);

        // --- STEP B: SIMPAN DETAIL BUKU KE TABEL 'detail_peminjaman' ---
        $sql_detail = "INSERT INTO detail_peminjaman (id_peminjaman, id_buku, jumlah) 
                       VALUES ('$id_peminjaman_baru', '$id_buku', '$jumlah_pinjam')";
        
        $simpan_detail = mysqli_query($conn, $sql_detail);

        if ($simpan_detail) {
            // --- STEP C: KURANGI STOK BUKU SECARA AMAN ---
            // Cek nama kolom stok di tabel buku (apakah 'stok' atau 'jumlah')
            $check_buku_cols = mysqli_query($conn, "SHOW COLUMNS FROM buku");
            $buku_cols = [];
            if ($check_buku_cols) {
                while ($bc = mysqli_fetch_assoc($check_buku_cols)) {
                    $buku_cols[] = strtolower($bc['Field']);
                }
            }

            if (in_array('stok', $buku_cols)) {
                @mysqli_query($conn, "UPDATE buku SET stok = stok - 1 WHERE id_buku = '$id_buku'");
            } elseif (in_array('jumlah', $buku_cols)) {
                @mysqli_query($conn, "UPDATE buku SET jumlah = jumlah - 1 WHERE id_buku = '$id_buku'");
            }

            echo "<script>
                    alert('Transaksi peminjaman berhasil disimpan!');
                    window.location.href = 'peminjaman.php';
                  </script>";
        } else {
            echo "<script>
                    alert('Gagal simpan detail peminjaman: " . addslashes(mysqli_error($conn)) . "');
                    window.history.back();
                  </script>";
        }

    } else {
        echo "<script>
                alert('Gagal simpan peminjaman: " . addslashes(mysqli_error($conn)) . "');
                window.history.back();
              </script>";
    }

} else {
    header("Location: peminjaman.php");
    exit();
}
?>
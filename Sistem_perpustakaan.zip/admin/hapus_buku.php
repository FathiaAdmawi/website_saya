<?php
session_start();

// Cek apakah admin sudah login
if (!isset($_SESSION['id_admin'])) {
    header("Location: ../login.php");
    exit();
}

include "../koneksi.php";

// Ambil ID Buku dari URL
if (isset($_GET['id'])) {
    $id_buku = $_GET['id'];

    // Hapus data buku berdasarkan id_buku
    $query = "DELETE FROM buku WHERE id_buku = '$id_buku'";
    
    if (mysqli_query($conn, $query)) {
        header("Location: buku.php");
        exit();
    } else {
        echo "Gagal menghapus buku: " . mysqli_error($conn);
    }
} else {
    header("Location: buku.php");
    exit();
}
?>
<?php
session_start();

// 1. Cek Login
if (!isset($_SESSION['id_admin']) && !isset($_SESSION['id_user']) && !isset($_SESSION['login'])) {
    // Silakan sesuaikan jika ada redirect
}

// 2. Load Koneksi Database
$koneksi_loaded = false;
$paths = ["../koneksi.php", "koneksi.php", "../config/koneksi.php", "../../koneksi.php"];

foreach ($paths as $path) {
    if (file_exists($path)) {
        include $path;
        $koneksi_loaded = true;
        break;
    }
}

if (!isset($conn) && isset($koneksi)) {
    $conn = $koneksi;
}

// 3. Filter Kategori & Pencarian
$kategori_filter = isset($_GET['kategori']) ? $_GET['kategori'] : '';
$search_query    = isset($_GET['search']) ? $_GET['search'] : '';

$sql = "SELECT * FROM buku WHERE 1=1";

if (!empty($kategori_filter) && isset($conn)) {
    $kategori_clean = mysqli_real_escape_string($conn, $kategori_filter);
    $sql .= " AND kategori LIKE '%$kategori_clean%'";
}

if (!empty($search_query) && isset($conn)) {
    $search_clean = mysqli_real_escape_string($conn, $search_query);
    $sql .= " AND (judul LIKE '%$search_clean%' OR pengarang LIKE '%$search_clean%' OR penerbit LIKE '%$search_clean%')";
}

// Pengurutan aman tanpa error
$sql .= " ORDER BY ";
if (isset($conn)) {
    $check_col = @mysqli_query($conn, "SHOW COLUMNS FROM buku LIKE 'id_buku'");
    if ($check_col && mysqli_num_rows($check_col) > 0) {
        $sql .= "id_buku DESC";
    } else {
        $sql .= "judul ASC";
    }
} else {
    $sql .= "1";
}

$query_buku = isset($conn) ? mysqli_query($conn, $sql) : false;

// PALET WARNA MIX: Campuran Warna Jreng/Nyentrik & Soft/Pudar
$top_colors = [
    // Warna Jreng / Nyentrik
    '#FF0055', // Hot Pink
    '#00E5FF', // Electric Cyan
    '#76FF03', // Neon Lime
    '#FF3D00', // Bright Orange
    '#D500F9', // Neon Purple
    '#FFD600', // Yellow Jreng
    
    // Warna Soft / Pudar
    '#B0BEC5', // Greyish Blue
    '#E1BEE7', // Soft Lavender
    '#FFCDD2', // Muted Pink
    '#C8E6C9', // Soft Mint
    '#FFE0B2', // Soft Peach
    '#D1C4E9'  // Muted Purple
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog Buku | Perpustakaan Digital</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <style>
        body { 
            background: #f0f3f8; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        @media (min-width: 768px) {
            .sidebar-fixed { position: fixed; top: 0; bottom: 0; left: 0; z-index: 100; overflow-y: auto; }
            .main-content { margin-left: 25%; }
        }
        @media (min-width: 992px) { 
            .main-content { margin-left: 16.66667%; } 
        }

        /* HEADER & BANNER ESTETIK */
        .catalog-header {
            background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            color: #ffffff;
            border-radius: 16px;
            padding: 1.25rem 1.5rem;
            box-shadow: 0 8px 20px rgba(0,0,0,0.06);
        }

        /* STYLING KARTU BUKU EKSTRA MUNGIL & KREM */
        .card-krem {
            background-color: #FDFBF7 !important; /* Warna Krem / Cream */
            border: 1px solid #ECE7DC;
            border-radius: 12px;
            overflow: hidden;
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .card-krem:hover {
            transform: translateY(-4px) scale(1.02);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.08) !important;
            border-color: #D8D0C0;
        }

        /* Garis Warna-Warni Top Bar */
        .top-color-bar {
            height: 4px;
            width: 100%;
        }

        /* BOX LOGO BUKU MUNGIL & INTERAKTIF */
        .logo-buku-box {
            height: 70px; /* Ukuran box diperkecil lagi */
            background: linear-gradient(180deg, #F5EFDF 0%, #EFE7D5 100%);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 0.4rem;
            border: 1px dashed #DDD2BD;
            transition: background 0.3s ease;
        }

        .card-krem:hover .logo-buku-box {
            background: linear-gradient(180deg, #EFE6D2 0%, #E8DFC9 100%);
        }

        .icon-circle {
            width: 38px;
            height: 38px;
            background-color: #FFFFFF;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
            box-shadow: 0 3px 6px rgba(0,0,0,0.08);
            transition: transform 0.3s ease;
        }

        .card-krem:hover .icon-circle {
            transform: scale(1.15) rotate(-5deg);
        }

        /* Badges Ukuran Mikro */
        .badge-kategori-clean {
            background-color: #EFE5D3;
            color: #5A4A3A;
            font-weight: 700;
            font-size: 0.58rem;
            padding: 2px 6px;
            border-radius: 8px;
        }

        .badge-stok-clean {
            background-color: #E0D5C1;
            color: #4A3E31;
            font-weight: 600;
            font-size: 0.58rem;
            padding: 2px 5px;
            border-radius: 6px;
        }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">

        <!-- SIDEBAR -->
        <div class="col-md-3 col-lg-2 bg-dark sidebar-fixed p-0">
            <?php 
            if (file_exists("../includes/sidebar.php")) { include "../includes/sidebar.php"; }
            elseif (file_exists("../sidebar.php")) { include "../sidebar.php"; }
            elseif (file_exists("sidebar.php")) { include "sidebar.php"; }
            ?>
        </div>

        <!-- KONTEN UTAMA -->
        <div class="col-md-9 col-lg-10 main-content p-3 p-md-4">

            <!-- HEADER KATALOG CANTIK -->
            <div class="catalog-header d-flex flex-wrap align-items-center justify-content-between mb-3 gap-2">
                <div>
                    <h3 class="fw-bold m-0 d-flex align-items-center gap-2">
                        <span>📚</span> Katalog Koleksi Buku
                    </h3>
                    <p class="text-white-50 small m-0 mt-1">
                        <?= !empty($kategori_filter) ? "Menampilkan Kategori: <span class='badge bg-warning text-dark'>" . htmlspecialchars($kategori_filter) . "</span>" : "Eksplorasi seluruh buku perpustakaan digital"; ?>
                    </p>
                </div>
                <div>
                    <a href="../dashboard.php" class="btn btn-sm btn-light rounded-pill px-3 py-1 fw-semibold text-dark shadow-sm">
                        <i class="bi bi-arrow-left"></i> Dashboard
                    </a>
                </div>
            </div>

            <!-- FORM FILTER & PENCARIAN -->
            <div class="card border-0 shadow-sm rounded-3 p-2 mb-3 bg-white">
                <form method="GET" action="katalog.php" class="row g-2 align-items-center">
                    <div class="col-md-5">
                        <div class="input-group input-group-sm">
                            <span class="input-group-text bg-light border-0"><i class="bi bi-search text-muted"></i></span>
                            <input type="text" name="search" class="form-control bg-light border-0" placeholder="Cari judul/pengarang..." value="<?= htmlspecialchars($search_query); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <select name="kategori" class="form-select form-select-sm bg-light border-0">
                            <option value="">-- Semua Kategori --</option>
                            <option value="Sains" <?= $kategori_filter == 'Sains' ? 'selected' : ''; ?>>Sains</option>
                            <option value="Novel" <?= $kategori_filter == 'Novel' ? 'selected' : ''; ?>>Novel</option>
                            <option value="Sejarah" <?= $kategori_filter == 'Sejarah' ? 'selected' : ''; ?>>Sejarah</option>
                            <option value="Horor" <?= $kategori_filter == 'Horor' ? 'selected' : ''; ?>>Horor</option>
                            <option value="Agama" <?= $kategori_filter == 'Agama' ? 'selected' : ''; ?>>Agama</option>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex gap-1">
                        <button type="submit" class="btn btn-sm btn-primary w-100 rounded-2">Cari</button>
                        <?php if (!empty($kategori_filter) || !empty($search_query)): ?>
                            <a href="katalog.php" class="btn btn-sm btn-light border rounded-2" title="Reset"><i class="bi bi-arrow-counterclockwise"></i></a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>

            <!-- GRID KARTU SANGAT MUNGIL & RAPI -->
            <div class="row g-2">
                <?php if ($query_buku && mysqli_num_rows($query_buku) > 0): ?>
                    <?php 
                    while ($buku = mysqli_fetch_assoc($query_buku)): 
                        // Ambil warna acak (mix jreng & pudar)
                        $accent_color = $top_colors[array_rand($top_colors)];
                        
                        // Kolom Data
                        $judul     = $buku['judul'] ?? $buku['judul_buku'] ?? 'Tanpa Judul';
                        $kategori  = $buku['kategori'] ?? 'Umum';
                        $pengarang = $buku['pengarang'] ?? $buku['penulis'] ?? '-';
                        $stok      = $buku['stok'] ?? $buku['jumlah'] ?? 0;
                    ?>
                        <!-- Grid Mungil: col-6 (HP), col-sm-3 (Tablet), col-md-2 / col-xl-2 (Desktop - Ringkas Sekali) -->
                        <div class="col-6 col-sm-3 col-md-2 col-xl-2">
                            <div class="card card-krem h-100 shadow-sm">
                                
                                <!-- AKSEN WARNA TOP-BAR -->
                                <div class="top-color-bar" style="background-color: <?= $accent_color; ?>;"></div>

                                <div class="card-body p-2 d-flex flex-column justify-content-between">
                                    <div>
                                        <!-- Badges Ringkas -->
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <span class="badge-kategori-clean text-truncate" style="max-width: 50px;"><?= htmlspecialchars($kategori); ?></span>
                                            <span class="badge-stok-clean">Stok: <?= $stok; ?></span>
                                        </div>

                                        <!-- BOX LOGO BUKU (Mungil & Interaktif) -->
                                        <div class="logo-buku-box">
                                            <div class="icon-circle">
                                                📖
                                            </div>
                                        </div>

                                        <!-- Judul Buku -->
                                        <div class="fw-bold text-dark mb-1 text-truncate" style="font-size: 0.75rem;" title="<?= htmlspecialchars($judul); ?>">
                                            <?= htmlspecialchars($judul); ?>
                                        </div>

                                        <!-- Pengarang -->
                                        <div class="text-muted mb-2 text-truncate" style="font-size: 0.65rem;">
                                            <i class="bi bi-person me-1"></i><?= htmlspecialchars($pengarang); ?>
                                        </div>
                                    </div>

                                    <!-- Tombol Detail -->
                                    <div class="pt-1 border-top">
                                        <a href="buku.php?search=<?= urlencode($judul); ?>" class="btn btn-xs btn-outline-secondary w-100 rounded-pill py-1 fw-semibold" style="font-size: 0.62rem;">
                                            <i class="bi bi-eye"></i> Detail
                                        </a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="col-12 text-center py-5">
                        <div class="bg-white p-4 rounded-3 shadow-sm">
                            <span class="fs-1 text-muted mb-2 d-block">🔍</span>
                            <h5 class="fw-bold">Buku Tidak Ditemukan</h5>
                            <p class="text-muted small">Coba gunakan kata kunci pencarian yang lain.</p>
                            <a href="katalog.php" class="btn btn-sm btn-primary rounded-pill px-3">Lihat Semua Buku</a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
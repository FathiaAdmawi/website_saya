<?php
session_start();
if (!isset($_SESSION['id_admin'])) {
    header("Location: ../login.php");
    exit();
}

include "../koneksi.php";

$id = $_GET['id'];
$get_buku = mysqli_query($conn, "SELECT * FROM buku WHERE id_buku = '$id'");
$buku = mysqli_fetch_assoc($get_buku);

if (!$buku) {
    header("Location: buku.php");
    exit();
}

if (isset($_POST['update'])) {
    $judul        = mysqli_real_escape_string($conn, $_POST['judul']);
    $pengarang    = mysqli_real_escape_string($conn, $_POST['pengarang']);
    $penerbit     = mysqli_real_escape_string($conn, $_POST['penerbit']);
    $tahun_terbit = mysqli_real_escape_string($conn, $_POST['tahun_terbit']);
    $stok         = mysqli_real_escape_string($conn, $_POST['stok']);

    $query = "UPDATE buku SET 
                judul='$judul', 
                pengarang='$pengarang', 
                penerbit='$penerbit', 
                tahun_terbit='$tahun_terbit', 
                stok='$stok' 
              WHERE id_buku='$id'";

    if (mysqli_query($conn, $query)) {
        header("Location: buku.php");
        exit();
    } else {
        $error = "Gagal memperbarui buku: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand">📚 Sistem Perpustakaan</a>
        <a href="buku.php" class="btn btn-light">Kembali</a>
    </div>
</nav>

<div class="container mt-4">
    <div class="card shadow col-md-8 mx-auto">
        <div class="card-header bg-warning text-dark">
            <h4 class="m-0">Edit Data Buku</h4>
        </div>
        <div class="card-body">
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?= $error; ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Judul Buku</label>
                    <input type="text" name="judul" value="<?= $buku['judul']; ?>" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Pengarang</label>
                    <input type="text" name="pengarang" value="<?= $buku['pengarang']; ?>" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Penerbit</label>
                    <input type="text" name="penerbit" value="<?= $buku['penerbit']; ?>" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Tahun Terbit</label>
                    <input type="number" name="tahun_terbit" value="<?= $buku['tahun_terbit']; ?>" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Stok</label>
                    <input type="number" name="stok" value="<?= $buku['stok']; ?>" class="form-control" required>
                </div>
                <button type="submit" name="update" class="btn btn-warning">Update Buku</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>
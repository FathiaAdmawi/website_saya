<?php
session_start();

// 1. Cek Status Login
if (!isset($_SESSION['id_admin']) && !isset($_SESSION['id_user'])) {
    header("Location: ../login.php");
    exit();
}

// 2. Load Koneksi Database
if (file_exists("../koneksi.php")) {
    include "../koneksi.php";
} elseif (file_exists("../config/koneksi.php")) {
    include "../config/koneksi.php";
}

if (!isset($conn) && isset($koneksi)) {
    $conn = $koneksi;
}

// 3. Filter Pencarian & Kategori
$search   = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$kategori = isset($_GET['kategori']) ? mysqli_real_escape_string($conn, $_GET['kategori']) : '';

$where_clause = "WHERE 1=1";
if (!empty($search)) {
    $where_clause .= " AND (judul LIKE '%$search%' OR pengarang LIKE '%$search%' OR penerbit LIKE '%$search%')";
}
if (!empty($kategori)) {
    $where_clause .= " AND kategori LIKE '%$kategori%'";
}

// 4. Query Ambil Data Buku
$query_sql = "SELECT * FROM buku $where_clause ORDER BY id_buku DESC";
$result    = mysqli_query($conn, $query_sql);

// Total Semua Buku
$q_total = mysqli_query($conn, "SELECT COUNT(*) as total, SUM(stok) as total_stok FROM buku");
$d_total = $q_total ? mysqli_fetch_assoc($q_total) : ['total' => 0, 'total_stok' => 0];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Koleksi Buku | Sistem Perpustakaan</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        body {
            background-color: #f4f6f9;
        }
        .navbar-custom {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        }
        .table-custom {
            border-radius: 12px;
            overflow: hidden;
        }
        .table-custom thead {
            background-color: #1e293b;
            color: #ffffff;
        }
        .card-stats {
            border: none;
            border-radius: 12px;
            transition: transform 0.2s ease;
        }
        .card-stats:hover {
            transform: translateY(-3px);
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom shadow-sm py-3">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold fs-4 d-flex align-items-center gap-2" href="../dashboard.php">
            <span>📚</span> Dashboard Perpustakaan
        </a>
        <a href="../dashboard.php" class="btn btn-light btn-sm fw-bold px-3 py-2 rounded-pill shadow-sm">
            <i class="bi bi-arrow-left"></i> Kembali ke Dashboard
        </a>
    </div>
</nav>

<div class="container-fluid px-4 py-4">

    <!-- HEADER TITLE & TOMBOL -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
        <div>
            <h2 class="fw-bold m-0 text-dark d-flex align-items-center gap-2">
                <span>📖</span> Daftar Koleksi Buku
            </h2>
            <p class="text-muted m-0">Kelola katalog dan stok buku perpustakaan dalam bentuk tabel data.</p>
        </div>
        <a href="tambah_buku.php" class="btn btn-primary fw-bold px-4 py-2 rounded-3 shadow-sm d-flex align-items-center gap-2">
            <i class="bi bi-plus-circle-fill"></i> Tambah Buku Baru
        </a>
    </div>

    <!-- STATISTIK RINGKAS BUKU -->
    <div class="row g-3 mb-4">
        <div class="col-md-6">
            <div class="card card-stats bg-white shadow-sm p-3 border-start border-primary border-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted fw-bold text-uppercase">Total Judul Buku</small>
                        <h3 class="fw-bold my-1 text-primary"><?= $d_total['total']; ?> Judul</h3>
                    </div>
                    <div class="fs-1 text-primary opacity-50"><i class="bi bi-journal-text"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card card-stats bg-white shadow-sm p-3 border-start border-success border-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted fw-bold text-uppercase">Total Fisik Stok Buku</small>
                        <h3 class="fw-bold my-1 text-success"><?= $d_total['total_stok'] ?? 0; ?> Eksemplar</h3>
                    </div>
                    <div class="fs-1 text-success opacity-50"><i class="bi bi-box-seam-fill"></i></div>
                </div>
            </div>
        </div>
    </div>

    <!-- FILTER PENCARIAN & KATEGORI -->
    <div class="card border-0 shadow-sm rounded-4 p-3 mb-4">
        <form method="GET" class="row g-2 align-items-center">
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
                    <input type="text" name="search" class="form-control border-start-0" placeholder="Cari judul, pengarang, atau penerbit..." value="<?= htmlspecialchars($search); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <select name="kategori" class="form-select" onchange="this.form.submit()">
                    <option value="">-- Semua Kategori --</option>
                    <option value="Sains" <?= $kategori == 'Sains' ? 'selected' : ''; ?>>Sains</option>
                    <option value="Novel" <?= $kategori == 'Novel' ? 'selected' : ''; ?>>Novel</option>
                    <option value="Sejarah" <?= $kategori == 'Sejarah' ? 'selected' : ''; ?>>Sejarah</option>
                    <option value="Horor" <?= $kategori == 'Horor' ? 'selected' : ''; ?>>Horor</option>
                    <option value="Agama" <?= $kategori == 'Agama' ? 'selected' : ''; ?>>Agama</option>
                </select>
            </div>
            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn btn-primary w-100 fw-semibold">Filter</button>
                <?php if(!empty($search) || !empty($kategori)): ?>
                    <a href="buku.php" class="btn btn-outline-secondary"><i class="bi bi-x-circle"></i></a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- TABEL DATA BUKU -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 table-custom">
                    <thead>
                        <tr class="text-center">
                            <th width="5%">No</th>
                            <th width="30%" class="text-start">Judul Buku</th>
                            <th width="20%" class="text-start">Pengarang</th>
                            <th width="15%">Kategori</th>
                            <th width="10%">Stok</th>
                            <th width="20%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && mysqli_num_rows($result) > 0): ?>
                            <?php $no = 1; while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td class="text-center fw-bold"><?= $no++; ?></td>
                                    <td>
                                        <div class="fw-bold text-dark fs-6"><?= htmlspecialchars($row['judul']); ?></div>
                                        <small class="text-muted">Penerbit: <?= htmlspecialchars($row['penerbit'] ?? '-'); ?> (<?= $row['tahun_terbit'] ?? '-'; ?>)</small>
                                    </td>
                                    <td>
                                        <span class="fw-semibold text-secondary">
                                            <i class="bi bi-person me-1"></i><?= htmlspecialchars($row['pengarang'] ?? '-'); ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-info-subtle text-info border border-info px-3 py-2 rounded-pill fw-bold">
                                            <?= htmlspecialchars($row['kategori']); ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <?php if ($row['stok'] > 0): ?>
                                            <span class="badge bg-success-subtle text-success border border-success px-3 py-2 rounded-pill fw-bold">
                                                <?= $row['stok']; ?> Buah
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-subtle text-danger border border-danger px-3 py-2 rounded-pill fw-bold">
                                                Habis
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <div class="d-flex justify-content-center gap-1">
                                            <a href="edit_buku.php?id=<?= $row['id_buku']; ?>" class="btn btn-warning btn-sm text-white fw-bold px-2 py-1">
                                                <i class="bi bi-pencil-square"></i> Edit
                                            </a>
                                            <a href="hapus_buku.php?id=<?= $row['id_buku']; ?>" class="btn btn-danger btn-sm fw-bold px-2 py-1" onclick="return confirm('Yakin ingin menghapus buku ini?')">
                                                <i class="bi bi-trash"></i> Hapus
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    <i class="bi bi-inbox display-4 d-block mb-2 text-secondary"></i>
                                    Belum ada data koleksi buku yang ditemukan.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
session_start();

// 1. Cek Status Login
if (!isset($_SESSION['id_admin']) && !isset($_SESSION['id_user'])) {
    header("Location: ../login.php");
    exit();
}

// 2. Load Koneksi Database
if (file_exists("../koneksi.php")) {
    include "../koneksi.php";
} elseif (file_exists("../config/koneksi.php")) {
    include "../config/koneksi.php";
}

if (!isset($conn) && isset($koneksi)) {
    $conn = $koneksi;
}

// 3. Filter Pencarian
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

$where_clause = "WHERE 1=1";
if (!empty($search)) {
    $where_clause .= " AND (p.nama_peminjam LIKE '%$search%' OR pg.id_peminjaman LIKE '%$search%')";
}

// 4. Query Data Pengembalian
$query_sql = "SELECT pg.*, p.nama_peminjam 
              FROM pengembalian pg
              LEFT JOIN peminjaman p ON pg.id_peminjaman = p.id_peminjaman
              $where_clause
              ORDER BY pg.id_pengembalian DESC";

$result = mysqli_query($conn, $query_sql);

// Query Ringkasan Statistik
$q_total_pengembalian = mysqli_query($conn, "SELECT COUNT(*) as total FROM pengembalian");
$total_pengembalian   = $q_total_pengembalian ? mysqli_fetch_assoc($q_total_pengembalian)['total'] : 0;

$q_total_denda        = mysqli_query($conn, "SELECT SUM(denda) as total_denda FROM pengembalian");
$total_denda          = $q_total_denda ? (mysqli_fetch_assoc($q_total_denda)['total_denda'] ?? 0) : 0;

$bulan_ini            = date('Y-m');
$q_bln_ini            = mysqli_query($conn, "SELECT COUNT(*) as total FROM pengembalian WHERE tgl_kembali LIKE '$bulan_ini%'");
$total_bln_ini        = $q_bln_ini ? mysqli_fetch_assoc($q_bln_ini)['total'] : 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pengembalian | Sistem Perpustakaan</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        body {
            background-color: #f4f6f9;
        }
        .navbar-custom {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        }
        .card-stats {
            border: none;
            border-radius: 12px;
            transition: transform 0.2s ease;
        }
        .card-stats:hover {
            transform: translateY(-3px);
        }
        .table-custom {
            border-radius: 12px;
            overflow: hidden;
        }
        .table-custom thead {
            background-color: #1e293b;
            color: #ffffff;
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom shadow-sm py-3">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold fs-4 d-flex align-items-center gap-2" href="../dashboard.php">
            <span>📚</span> Dashboard Perpustakaan
        </a>
        <a href="../dashboard.php" class="btn btn-light btn-sm fw-bold px-3 py-2 rounded-pill shadow-sm">
            <i class="bi bi-arrow-left"></i> Kembali ke Dashboard
        </a>
    </div>
</nav>

<div class="container-fluid px-4 py-4">

    <!-- HEADER TITLE -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
        <div>
            <h2 class="fw-bold m-0 text-dark d-flex align-items-center gap-2">
                <i class="bi bi-arrow-repeat text-primary"></i> Data Pengembalian Buku
            </h2>
            <p class="text-muted m-0">Daftar riwayat buku yang sudah berhasil dikembalikan oleh peminjam.</p>
        </div>
    </div>

    <!-- CARDS STATISTIK BERWARNA -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card card-stats bg-white shadow-sm p-3 border-start border-success border-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted fw-bold text-uppercase">Total Pengembalian</small>
                        <h3 class="fw-bold my-1 text-success"><?= $total_pengembalian; ?> Transaksi</h3>
                    </div>
                    <div class="fs-1 text-success opacity-50"><i class="bi bi-check2-circle"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-stats bg-white shadow-sm p-3 border-start border-danger border-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted fw-bold text-uppercase">Total Denda Terkumpul</small>
                        <h3 class="fw-bold my-1 text-danger">Rp <?= number_format($total_denda, 0, ',', '.'); ?></h3>
                    </div>
                    <div class="fs-1 text-danger opacity-50"><i class="bi bi-cash-stack"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-stats bg-white shadow-sm p-3 border-start border-info border-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted fw-bold text-uppercase">Pengembalian Bulan Ini</small>
                        <h3 class="fw-bold my-1 text-info"><?= $total_bln_ini; ?> Transaksi</h3>
                    </div>
                    <div class="fs-1 text-info opacity-50"><i class="bi bi-calendar-check-fill"></i></div>
                </div>
            </div>
        </div>
    </div>

    <!-- FILTER PENCARIAN -->
    <div class="card border-0 shadow-sm rounded-4 p-3 mb-4">
        <form method="GET" class="row g-2 align-items-center">
            <div class="col-md-10">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
                    <input type="text" name="search" class="form-control border-start-0" placeholder="Cari berdasarkan nama peminjam atau ID Peminjaman..." value="<?= htmlspecialchars($search); ?>">
                </div>
            </div>
            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn btn-primary w-100 fw-semibold">Cari Data</button>
                <?php if(!empty($search)): ?>
                    <a href="pengembalian.php" class="btn btn-outline-secondary"><i class="bi bi-x-circle"></i></a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- TABEL DATA PENGEMBALIAN -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 table-custom">
                    <thead>
                        <tr class="text-center">
                            <th width="5%">No</th>
                            <th width="15%">ID Peminjaman</th>
                            <th width="30%">Nama Peminjam</th>
                            <th width="20%">Tanggal Kembali</th>
                            <th width="15%">Denda</th>
                            <th width="15%">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && mysqli_num_rows($result) > 0): ?>
                            <?php $no = 1; while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td class="text-center fw-bold"><?= $no++; ?></td>
                                    <td class="text-center">
                                        <span class="badge bg-secondary-subtle text-secondary border border-secondary px-3 py-2 rounded-pill fw-bold">
                                            #PMJ-<?= str_pad($row['id_peminjaman'], 4, '0', STR_PAD_LEFT); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="fw-bold text-dark fs-6">
                                            <?= !empty($row['nama_peminjam']) ? htmlspecialchars($row['nama_peminjam']) : 'Pengunjung Umum'; ?>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-light text-dark border px-3 py-2 fw-semibold">
                                            <i class="bi bi-calendar-check text-success me-1"></i> <?= !empty($row['tgl_kembali']) ? $row['tgl_kembali'] : '-'; ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <?php if (!empty($row['denda']) && $row['denda'] > 0): ?>
                                            <span class="badge bg-danger-subtle text-danger border border-danger px-3 py-2 rounded-pill fw-bold">
                                                Rp <?= number_format($row['denda'], 0, ',', '.'); ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-success-subtle text-success border border-success px-3 py-2 rounded-pill fw-bold">
                                                Tidak Ada
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-success text-white px-3 py-2 rounded-pill fw-bold shadow-sm">
                                            <i class="bi bi-check-circle-fill me-1"></i> Dikembalikan
                                        </span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    <div class="py-4">
                                        <i class="bi bi-inbox display-3 d-block mb-3 text-secondary opacity-50"></i>
                                        <h5 class="fw-bold text-secondary">Belum ada data transaksi pengembalian buku.</h5>
                                        <p class="text-muted small m-0">Semua riwayat pengembalian buku yang telah diproses akan muncul di sini.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
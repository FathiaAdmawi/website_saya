<?php
session_start();

// Cek status login
if (!isset($_SESSION['id_admin'])) {
    header("Location: ../login.php");
    exit();
}

include "../koneksi.php";

// ==========================================
// 1. PROSES HAPUS BUKU
// ==========================================
if (isset($_GET['action']) && $_GET['action'] == 'hapus') {
    $id_buku = intval($_GET['id']);
    $query_delete = "DELETE FROM buku WHERE id_buku = '$id_buku'";
    if (mysqli_query($conn, $query_delete)) {
        header("Location: tambah_buku.php?status=deleted");
        exit();
    } else {
        $error = "Gagal menghapus buku: " . mysqli_error($conn);
    }
}

// ==========================================
// 2. PROSES SIMPAN BUKU BARU (LANGKAH 1 SAFE FIX)
// ==========================================
if (isset($_POST['simpan'])) {
    $judul        = mysqli_real_escape_string($conn, $_POST['judul']);
    $pengarang    = mysqli_real_escape_string($conn, $_POST['pengarang']);
    $penerbit     = mysqli_real_escape_string($conn, $_POST['penerbit']);
    $tahun_terbit = intval($_POST['tahun_terbit']);
    $stok         = intval($_POST['stok']);
    
    // Ambil array kategori dari form multi-select
    $kategori_arr = $_POST['kategori'] ?? [];
    $kategori_str = !empty($kategori_arr) ? implode(", ", $kategori_arr) : 'Umum';
    $kategori_simpan = mysqli_real_escape_string($conn, $kategori_str);

    // Ambil ID Kategori pertama agar aman dari error Foreign Key
    $id_kategori_default = 1;
    if (!empty($kategori_arr)) {
        $first_kat = mysqli_real_escape_string($conn, $kategori_arr[0]);
        $q_kat = mysqli_query($conn, "SELECT id_kategori FROM kategori WHERE nama_kategori = '$first_kat' LIMIT 1");
        if ($q_kat && mysqli_num_rows($q_kat) > 0) {
            $row_kat = mysqli_fetch_assoc($q_kat);
            $id_kategori_default = $row_kat['id_kategori'];
        }
    }

    // Cek apakah kolom 'kategori' baru sudah dibuat di database
    $check_column = mysqli_query($conn, "SHOW COLUMNS FROM buku LIKE 'kategori'");
    $has_kategori_column = (mysqli_num_rows($check_column) > 0);

    if ($has_kategori_column) {
        // Simpan ke kolom 'kategori' yang baru kita buat
        $query_insert = "INSERT INTO buku (judul, pengarang, penerbit, tahun_terbit, stok, id_kategori, kategori) 
                        VALUES ('$judul', '$pengarang', '$penerbit', '$tahun_terbit', '$stok', '$id_kategori_default', '$kategori_simpan')";
    } else {
        // Jika belum buat kolom, simpan standar
        $query_insert = "INSERT INTO buku (judul, pengarang, penerbit, tahun_terbit, stok, id_kategori) 
                        VALUES ('$judul', '$pengarang', '$penerbit', '$tahun_terbit', '$stok', '$id_kategori_default')";
    }

    if (mysqli_query($conn, $query_insert)) {
        header("Location: tambah_buku.php?status=success");
        exit();
    } else {
        $error = "Gagal menyimpan buku: " . mysqli_error($conn);
    }
}

// ==========================================
// 3. AMBIL DATA BUKU
// ==========================================
$query_buku = "SELECT * FROM buku ORDER BY id_buku DESC";
$result_buku = mysqli_query($conn, $query_buku);

// Daftar Pilihan Kategori
$daftar_kategori = ['Novel', 'Sains', 'Pendidikan', 'Agama', 'Teknologi', 'Sejarah', 'Misteri', 'Horor'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Data Buku | Sistem Perpustakaan</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Select2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />

    <style>
        .select2-container--bootstrap-5 .select2-selection {
            min-height: 38px;
            border-radius: 0.375rem;
        }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand fw-bold" href="../dashboard.php">📚 Dashboard Perpustakaan</a>
        <a href="../dashboard.php" class="btn btn-light btn-sm fw-semibold">Kembali ke Dashboard</a>
    </div>
</nav>

<div class="container mb-5">

    <!-- Notifikasi Pesan -->
    <?php if (isset($_GET['status']) && $_GET['status'] == 'success'): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            ✨ Buku berhasil ditambahkan!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['status']) && $_GET['status'] == 'deleted'): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            🗑️ Buku berhasil dihapus!
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            ⚠️ <strong>Error:</strong> <?= $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h3 class="fw-bold mb-0">Daftar Data Buku</h3>
            <p class="text-muted mb-0">Kelola koleksi buku perpustakaan kamu di sini.</p>
        </div>
        <a href="#formTambah" class="btn btn-success fw-semibold">➕ Tambah Buku Baru</a>
    </div>

    <!-- FORM INPUT TAMBAH BUKU -->
    <div class="card border-0 shadow-sm mb-4" id="formTambah">
        <div class="card-header bg-primary text-white">
            <h5 class="m-0 fw-bold">Form Tambah Buku Baru</h5>
        </div>
        <div class="card-body p-4">
            <form method="POST">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Judul Buku</label>
                        <input type="text" name="judul" class="form-control" placeholder="Masukkan judul buku" required>
                    </div>

                    <!-- DROPDOWN MULTI-SELECT KATEGORI -->
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Kategori Buku</label>
                        <select name="kategori[]" class="form-select select2-kategori" multiple="multiple" data-placeholder="Pilih satu atau lebih kategori..." required>
                            <?php foreach ($daftar_kategori as $kat): ?>
                                <option value="<?= $kat; ?>"><?= $kat; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Pengarang</label>
                        <input type="text" name="pengarang" class="form-control" placeholder="Masukkan nama pengarang" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Penerbit</label>
                        <input type="text" name="penerbit" class="form-control" placeholder="Masukkan penerbit" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Tahun Terbit</label>
                        <input type="number" name="tahun_terbit" class="form-control" placeholder="Contoh: 2024" min="1900" max="2099" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Stok Buku</label>
                        <input type="number" name="stok" class="form-control" placeholder="Jumlah stok" min="1" required>
                    </div>
                </div>

                <div class="mt-4">
                    <button type="submit" name="simpan" class="btn btn-success fw-semibold">💾 Simpan Buku</button>
                </div>
            </form>
        </div>
    </div>

    <!-- TABEL DAFTAR BUKU -->
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white py-3">
            <h5 class="m-0 fw-bold">Daftar Buku Terdaftar</h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-3">No</th>
                            <th>Judul Buku</th>
                            <th>Kategori</th>
                            <th>Pengarang</th>
                            <th>Penerbit</th>
                            <th>Tahun</th>
                            <th>Stok</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result_buku && mysqli_num_rows($result_buku) > 0): ?>
                            <?php $no = 1; while ($buku = mysqli_fetch_assoc($result_buku)): ?>
                            <tr>
                                <td class="ps-3"><?= $no++; ?></td>
                                <td class="fw-semibold"><?= htmlspecialchars($buku['judul']); ?></td>
                                <td>
                                    <?php 
                                    // Mengambil nama kategori yang tersimpan
                                    $kat_text = !empty($buku['kategori']) ? $buku['kategori'] : ($buku['id_kategori'] ?? 'Umum');
                                    $kats = explode(', ', $kat_text);
                                    foreach ($kats as $k) {
                                        echo '<span class="badge bg-info text-dark me-1 mb-1">' . htmlspecialchars($k) . '</span>';
                                    }
                                    ?>
                                </td>
                                <td><?= htmlspecialchars($buku['pengarang']); ?></td>
                                <td><?= htmlspecialchars($buku['penerbit']); ?></td>
                                <td><?= htmlspecialchars($buku['tahun_terbit']); ?></td>
                                <td>
                                    <span class="badge bg-<?= $buku['stok'] > 0 ? 'success' : 'danger'; ?>">
                                        <?= $buku['stok']; ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <a href="tambah_buku.php?action=hapus&id=<?= $buku['id_buku']; ?>" 
                                       class="btn btn-danger btn-sm" 
                                       onclick="return confirm('Yakin ingin menghapus buku ini?');">
                                        🗑️ Hapus
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">Belum ada data buku.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<!-- Script JS -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('.select2-kategori').select2({
            theme: 'bootstrap-5',
            width: '100%',
            placeholder: $(this).data('placeholder'),
            closeOnSelect: false
        });
    });
</script>
</body>
</html>
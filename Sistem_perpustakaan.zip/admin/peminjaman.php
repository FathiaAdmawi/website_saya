<?php
session_start();

// 1. Cek Status Login
if (!isset($_SESSION['id_admin']) && !isset($_SESSION['id_user'])) {
    header("Location: ../login.php");
    exit();
}

// 2. Load Koneksi Database
if (file_exists("../koneksi.php")) {
    include "../koneksi.php";
} elseif (file_exists("../config/koneksi.php")) {
    include "../config/koneksi.php";
}

if (!isset($conn) && isset($koneksi)) {
    $conn = $koneksi;
}

// 3. Filter Pencarian & Status
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$filter_status = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : '';

$where_clause = "WHERE 1=1";
if (!empty($search)) {
    $where_clause .= " AND (p.nama_peminjam LIKE '%$search%' OR b.judul LIKE '%$search%')";
}
if (!empty($filter_status)) {
    $where_clause .= " AND p.status = '$filter_status'";
}

// 4. Query Ambil Data Peminjaman + Join Buku
$query_sql = "SELECT p.*, b.judul AS judul_buku 
              FROM peminjaman p 
              LEFT JOIN detail_peminjaman dp ON p.id_peminjaman = dp.id_peminjaman
              LEFT JOIN buku b ON dp.id_buku = b.id_buku 
              $where_clause 
              GROUP BY p.id_peminjaman 
              ORDER BY p.id_peminjaman DESC";

$result = mysqli_query($conn, $query_sql);

// Query Statistik
$total_transaksi   = mysqli_num_rows(mysqli_query($conn, "SELECT id_peminjaman FROM peminjaman"));
$total_dipinjam    = mysqli_num_rows(mysqli_query($conn, "SELECT id_peminjaman FROM peminjaman WHERE status='Dipinjam' OR status IS NULL"));
$total_kembali     = mysqli_num_rows(mysqli_query($conn, "SELECT id_peminjaman FROM peminjaman WHERE status='Dikembalikan' OR status='Selesai'"));
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi Peminjaman | Sistem Perpustakaan</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        body {
            background-color: #f4f6f9;
        }
        .navbar-custom {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        }
        .card-stats {
            border: none;
            border-radius: 12px;
            transition: transform 0.2s;
        }
        .card-stats:hover {
            transform: translateY(-3px);
        }
        .table-custom {
            border-radius: 10px;
            overflow: hidden;
        }
        .table-custom thead {
            background-color: #1e293b;
            color: #ffffff;
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark navbar-custom shadow-sm py-3">
    <div class="container-fluid px-4">
        <a class="navbar-brand fw-bold fs-4 d-flex align-items-center gap-2" href="../dashboard.php">
            <span>📚</span> Dashboard Perpustakaan
        </a>
        <a href="../dashboard.php" class="btn btn-light btn-sm fw-bold px-3 py-2 rounded-pill shadow-sm">
            <i class="bi bi-arrow-left"></i> Kembali ke Dashboard
        </a>
    </div>
</nav>

<div class="container-fluid px-4 py-4">

    <!-- HEADER TITLE & BUTTON -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
        <div>
            <h2 class="fw-bold m-0 text-dark">📋 Transaksi Peminjaman</h2>
            <p class="text-muted m-0">Kelola riwayat dan transaksi peminjaman buku perpustakaan.</p>
        </div>
        <a href="tambah_peminjaman.php" class="btn btn-success fw-bold px-4 py-2 rounded-3 shadow-sm d-flex align-items-center gap-2">
            <i class="bi bi-plus-circle-fill"></i> Transaksi Baru
        </a>
    </div>

    <!-- CARDS RINGKASAN STATISTIK -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card card-stats bg-white shadow-sm p-3 border-start border-primary border-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted fw-bold text-uppercase">Total Transaksi</small>
                        <h3 class="fw-bold my-1 text-primary"><?= $total_transaksi; ?></h3>
                    </div>
                    <div class="fs-1 text-primary opacity-50"><i class="bi bi-journal-bookmark-fill"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-stats bg-white shadow-sm p-3 border-start border-warning border-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted fw-bold text-uppercase">Sedang Dipinjam</small>
                        <h3 class="fw-bold my-1 text-warning"><?= $total_dipinjam; ?></h3>
                    </div>
                    <div class="fs-1 text-warning opacity-50"><i class="bi bi-clock-history"></i></div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-stats bg-white shadow-sm p-3 border-start border-success border-4">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted fw-bold text-uppercase">Sudah Dikembalikan</small>
                        <h3 class="fw-bold my-1 text-success"><?= $total_kembali; ?></h3>
                    </div>
                    <div class="fs-1 text-success opacity-50"><i class="bi bi-check-circle-fill"></i></div>
                </div>
            </div>
        </div>
    </div>

    <!-- FILTER & PENCARIAN -->
    <div class="card border-0 shadow-sm rounded-4 p-3 mb-4">
        <form method="GET" class="row g-2 align-items-center">
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
                    <input type="text" name="search" class="form-control border-start-0" placeholder="Cari nama peminjam atau judul buku..." value="<?= htmlspecialchars($search); ?>">
                </div>
            </div>
            <div class="col-md-4">
                <select name="status" class="form-select" onchange="this.form.submit()">
                    <option value="">-- Semua Status --</option>
                    <option value="Dipinjam" <?= $filter_status == 'Dipinjam' ? 'selected' : ''; ?>>Dipinjam</option>
                    <option value="Dikembalikan" <?= $filter_status == 'Dikembalikan' ? 'selected' : ''; ?>>Dikembalikan</option>
                </select>
            </div>
            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn btn-primary w-100 fw-semibold">Filter</button>
                <?php if(!empty($search) || !empty($filter_status)): ?>
                    <a href="peminjaman.php" class="btn btn-outline-secondary"><i class="bi bi-x-circle"></i></a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- TABEL DATA PEMINJAMAN -->
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0 table-custom">
                    <thead>
                        <tr class="text-center">
                            <th width="5%">No</th>
                            <th width="22%">Nama Peminjam</th>
                            <th width="28%">Judul Buku</th>
                            <th width="15%">Tanggal Pinjam</th>
                            <th width="15%">Tanggal Kembali</th>
                            <th width="15%">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && mysqli_num_rows($result) > 0): ?>
                            <?php $no = 1; while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td class="text-center fw-bold"><?= $no++; ?></td>
                                    <td>
                                        <div class="fw-bold text-dark fs-6">
                                            <?= !empty($row['nama_peminjam']) ? htmlspecialchars($row['nama_peminjam']) : 'Pengunjung Umum'; ?>
                                        </div>
                                        <?php if(!empty($row['umur'])): ?>
                                            <small class="text-muted"><?= $row['umur']; ?> Thn <?= !empty($row['jenis_kelamin']) ? '| '.$row['jenis_kelamin'] : ''; ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="fw-semibold text-primary">
                                            <?= !empty($row['judul_buku']) ? htmlspecialchars($row['judul_buku']) : '<span class="text-muted fs-7">Buku Tidak Ditemukan</span>'; ?>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-light text-dark border px-3 py-2 fw-semibold">
                                            <i class="bi bi-calendar-event me-1 text-primary"></i> <?= !empty($row['tgl_pinjam']) ? $row['tgl_pinjam'] : '-'; ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-light text-dark border px-3 py-2 fw-semibold">
                                            <i class="bi bi-calendar-check me-1 text-danger"></i> <?= !empty($row['tgl_kembali']) ? $row['tgl_kembali'] : '-'; ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <?php 
                                        $status = $row['status'] ?? 'Dipinjam';
                                        if (strtolower($status) == 'dikembalikan' || strtolower($status) == 'selesai') {
                                            echo '<span class="badge bg-success-subtle text-success border border-success px-3 py-2 rounded-pill fw-bold"><i class="bi bi-check-circle me-1"></i> Dikembalikan</span>';
                                        } else {
                                            echo '<span class="badge bg-warning-subtle text-warning border border-warning px-3 py-2 rounded-pill fw-bold text-dark"><i class="bi bi-hourglass-split me-1"></i> Dipinjam</span>';
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    <i class="bi bi-inbox display-4 d-block mb-2 text-secondary"></i>
                                    Belum ada data peminjaman yang ditemukan.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
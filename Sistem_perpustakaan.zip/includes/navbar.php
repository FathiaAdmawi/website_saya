<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow">
    <div class="container-fluid">

        <a class="navbar-brand fw-bold" href="dashboard.php">
            📚 Sistem Manajemen Perpustakaan
        </a>

        <div class="ms-auto text-white">
            Selamat Datang,
            <strong><?php echo $_SESSION['nama']; ?></strong>
        </div>

    </div>
</nav>
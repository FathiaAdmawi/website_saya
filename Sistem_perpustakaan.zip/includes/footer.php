<footer class="bg-primary text-white text-center py-3 mt-auto">
    <div class="container">
        <small>© <?= date('Y'); ?> Sistem Manajemen Perpustakaan. All rights reserved.</small>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
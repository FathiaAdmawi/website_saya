<style>
    /* Styling khusus untuk menu sidebar */
    .sidebar-menu .list-group-item {
        font-size: 1.15rem !important; /* Memperbesar ukuran teks menu */
        transition: background-color 0.15s ease, color 0.15s ease;
    }

    /* Efek saat kursor diarahkan (Hover) */
    .sidebar-menu .list-group-item:hover {
        background-color: rgba(255, 255, 255, 0.1) !important; /* Efek sorot halus saat di-hover */
        color: #ffffff !important;
    }

    /* Efek SAAT DIKLIK SAJA (Active / Ditekan) */
    .sidebar-menu .list-group-item:active {
        background-color: #6c757d !important; /* Berubah menjadi warna ABU-ABU pas diklik */
        color: #ffffff !important;
    }
</style>

<div class="p-3 text-white sidebar-menu">
    <!-- Judul Header Menu -->
    <h4 class="mb-4 text-primary fw-bold text-uppercase fs-4 border-bottom border-secondary pb-2">
        MENU UTAMA
    </h4>

    <div class="list-group list-group-flush">
        <!-- Dashboard -->
        <a href="dashboard.php" class="list-group-item list-group-item-action bg-transparent text-white border-0 py-3 fw-semibold rounded mb-2">
            🏠 Dashboard
        </a>

        <!-- Data Buku -->
        <a href="admin/buku.php" class="list-group-item list-group-item-action bg-transparent text-white border-0 py-3 fw-semibold rounded mb-2">
            📚 Data Buku
        </a>

        <!-- Data Anggota -->
        <a href="admin/anggota.php" class="list-group-item list-group-item-action bg-transparent text-white border-0 py-3 fw-semibold rounded mb-2">
            👥 Data Anggota
        </a>

        <!-- Peminjaman -->
        <a href="admin/peminjaman.php" class="list-group-item list-group-item-action bg-transparent text-white border-0 py-3 fw-semibold rounded mb-2">
            📖 Peminjaman
        </a>

        <!-- Pengembalian -->
        <a href="admin/pengembalian.php" class="list-group-item list-group-item-action bg-transparent text-white border-0 py-3 fw-semibold rounded mb-2">
            🔄 Pengembalian
        </a>

        <hr class="text-secondary my-3">

        <!-- Logout -->
        <a href="logout.php" class="list-group-item list-group-item-action bg-transparent text-danger border-0 py-3 fw-bold rounded mb-2">
            🚪 Logout
        </a>
    </div>
</div>